export const environment = {
  production: true,
  apiUrl: 'https://policyplanner.com/health-insurance/'
};
